package modelServiceInterface;

import java.util.List;

public interface BinhLuanChoTungSachInterface {

	//lay comment som nhat (5 cai)
	
	//nhap comment, danh gia user id, product id, 

	//
}
