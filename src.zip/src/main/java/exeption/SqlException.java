package exeption;

public class SqlException extends Exception {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public SqlException(String mess) {
		super(mess);
	}
}
