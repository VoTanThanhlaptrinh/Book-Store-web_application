package service;

public interface ISendMailService {
	void sendMail(String email, String content,String subject);

}
